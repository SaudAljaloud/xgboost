from setuptools import setup

setup(name='sparkxgb',
      version='0.1',
      description='sparkxgb for soark',
      url='https://github.com/dmlc/xgboost/files/2161553/sparkxgb.zip',
      author='sparkxgb',
      author_email='sparkxgb@example.com',
      license='MIT'
      )